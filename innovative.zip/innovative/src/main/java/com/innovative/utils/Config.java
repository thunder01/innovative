package com.innovative.utils;

public class Config {


    //文件上传路径(测试)
    public static final  String FILE_URL = "/data/images/";

    //文件上传路径(正式)
    //public static final  String FILE_URL = "/data/file/";


}
