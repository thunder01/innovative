package com.innovative.service;


import com.innovative.bean.Solution;
import com.innovative.dao.SolutionDao;
import com.innovative.utils.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SolutionService {

    @Autowired
    private SolutionDao solutionDao;


    /**
     * 根据id获取方案
     *
     * @param id 方案id
     * @return
     */
    public Solution getSolutionById(Integer id) {

        return solutionDao.getSolutionById(id);

    }

    /**
     * 分页条件查询方案list
     *
     * @param pageNum  页码
     * @return
     */
    public Map<String, Object> getSolutionListByCondition(int pageNum) {


      /*  if (sectors != null) {
            sectors = "{" + sectors + "}";
        }
*/
        //获取分页信息
        PageInfo pageInfo = new PageInfo();
        pageInfo.setCurrentPageNum(pageNum);
        int offset = pageInfo.getStartIndex();
        int limit = pageInfo.getPageSize();

        //分页条件查询
        List<Solution> items = solutionDao.getSolutionListByCondition( offset, limit);
        int totalCount = solutionDao.getCountByCondition();

        //数据组装
        Map<String, Object> map = new HashMap<>();
        map.put("items", items);
        map.put("totalCount", totalCount);
        map.put("Count", pageInfo.getPageSize());
        map.put("itemCount", pageInfo.getPageSize());
        map.put("offset", pageInfo.getStartIndex());
        map.put("limit", pageInfo.getPageSize());

        return map;

    }

    /**
     * 新增技术报告
     *
     * @param solution 参数集合
     * @return
     */
    public boolean insertSolution(Solution solution) {

        int result = solutionDao.insertSolution(solution);

        return result > 0 ? true : false;
    }

    /**
     * 修改技术报告信息
     *
     * @param solution 参数集合
     * @return
     */
    public boolean updateSolution(Solution solution) {

        int result = solutionDao.updateSolution(solution);

        return result > 0 ? true : false;
    }
}
