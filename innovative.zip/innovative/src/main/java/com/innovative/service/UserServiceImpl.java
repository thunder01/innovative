package com.innovative.service;

import javax.jws.WebService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.innovative.dao.UserDao;



@WebService(serviceName = "UserService",targetNamespace="http://service.innovative.com",endpointInterface="com.innovative.service.UserService")
@Component
public class UserServiceImpl implements UserService {
 
	@Autowired
	UserDao userdao;

	/*@Override
	public JsonResult addUserList(List<User> userList) {
		// TODO Auto-generated method stub
		int usernum = userdao.insertUserList(userList);
		if (usernum<=0){
			return new JsonResult(false,"数据接收失败");
		}
		return new JsonResult(true,"成功接收"+usernum+"记录");
	}*/


	/*@Override
	public String addUser(String userId, String userName, String userPost, String userSex, String userAge) {
		boolean flag = userdao.insertUser(userId,userName,userPost,userSex,userAge);
		if (!flag){
			return "数据接收失败";
		}f
		return "成功接收用户信息";
	}*/
	@Override
	public String sayHello( String name) {
		return "hello:"+name;
	}

	@Override
	public Boolean addUser(String userId, String userName, String userPost, String userSex, Integer userAge) {
		// TODO Auto-generated method stub
				boolean flag = userdao.insertUser(userId,userName,userPost,userSex,userAge);
				if (!flag){
					return false;
				}
				return true;
	}


}
