package com.innovative.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(name = "UserService",targetNamespace = "service.innovative.com")
public interface UserService { 
	/* @WebMethod
	 JsonResult addUserList(@WebParam(name = "userList") List<User> userList);*/
	 /*@WebMethod
	 @WebResult(name = "String", targetNamespace = "")
	 String addUser(@WebParam(name = "userId") String userId,@WebParam(name = "userName") String userName,@WebParam(name = "userPost") String userPost,@WebParam(name = "userSex") String userSex,@WebParam(name = "userAge") String userAge);*/
	 @WebMethod
	 @WebResult(name = "String", targetNamespace = "")
	 String sayHello(@WebParam(name = "userName") String name);
	 @WebMethod
	 Boolean addUser(@WebParam(name = "userId") String userId,@WebParam(name = "userName") String userName,@WebParam(name = "userPost") String userPost,@WebParam(name = "userSex") String userSex,@WebParam(name = "userAge") Integer userAge);
}
