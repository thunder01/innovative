package com.innovative.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.innovative.bean.User;


public interface  UserDao {
	
		int insertUserList(List<User> userList);
		boolean insertUser(@Param("userId") String userId,@Param("userName") String userName,@Param("userPost") String userPost,@Param("userSex") String userSex, @Param("userAge") Integer userAge);
}

